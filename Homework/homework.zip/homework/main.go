package main

import "github.com/kataras/iris"

func main() {
	app := iris.New()

	tmpl := iris.HTML("./view", ".html")
	tmpl.Layout("layout.html")
	tmpl.Reload(true)
	app.RegisterView(tmpl)

	app.StaticWeb("/resources", "./resources")
	app.Get("/san-pham", GetShop)
	app.Get("/san-pham/{id}", GetProductById)
	app.Get("/tao-san-pham", GetCreateProductPage)
	app.Post("/tao-san-pham", CreateProduct)

	app.Run(iris.Addr(":8080"))
}

func GetShop(ctx iris.Context) {
	ctx.View("shop.html")
}

func GetProductById(ctx iris.Context) {
	ctx.View("product.html")
}

func GetCreateProductPage(ctx iris.Context) {
	ctx.ViewLayout(iris.NoLayout)
	ctx.View("create.html")
}

func CreateProduct(ctx iris.Context) {

}
