package constant

const (
	// Trạng thái bài viết 
	DRAFT_POST  int32 = 0
	PUBLIC_POST int32 = 1
)