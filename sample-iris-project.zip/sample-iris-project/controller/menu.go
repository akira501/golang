package controller

import "github.com/kataras/iris"

func (c *Controller) GetMenu(ctx iris.Context) {
	// Viết code ở đây 

	ctx.ViewData("TitlePage", "Menu")
	ctx.View("/menu/index.html")
}

func (c *Controller) GetIndex(ctx iris.Context) {
	ctx.ViewLayout(iris.NoLayout)
	ctx.View("index.html")
}
