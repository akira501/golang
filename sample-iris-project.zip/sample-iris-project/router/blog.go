package router

import (
	"sample-project/controller"

	"github.com/kataras/iris"
)

func BlogRoutes(c *controller.Controller, api *iris.Application) {
	api.Get("/blog", c.GetBlog)
	api.Get("/blog/{id}", c.GetPostById)
	api.Get("/menu", c.GetMenu)
	api.Get("/", c.GetIndex)
}
